package bgu.spl.mics;

public class AttackEventExample implements Event<Boolean> {

}