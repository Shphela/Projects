package bgu.spl.mics;


public class simpleMicroservice2 extends MicroService {

    public simpleMicroservice2() {
        super("simple2");
    }


    @Override
    protected void initialize() {

    }
}
