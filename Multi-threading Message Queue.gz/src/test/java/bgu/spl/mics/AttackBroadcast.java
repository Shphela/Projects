package bgu.spl.mics;

public class AttackBroadcast implements Broadcast{
//    private String senderId;

    public AttackBroadcast() {
//        this.senderId = senderId;
    }

//    public String getSenderId() {
//        return senderId;
//    }

}
