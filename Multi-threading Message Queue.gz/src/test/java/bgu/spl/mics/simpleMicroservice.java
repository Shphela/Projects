package bgu.spl.mics;


public class simpleMicroservice extends MicroService {

    public simpleMicroservice() {
        super("simple1");
    }


    @Override
    protected void initialize() {

    }
}
