//
// Created by spl211 on 17/11/2020.
//

#include <vector>

#include "../include/Graph.h"

Graph::Graph(std::vector<std::vector<int>> matrix):edges(matrix),infectedVertices(),infectedQueue(){
    std::vector<bool>temp(matrix.size(),false);
    this->infectedVertices=temp;


}
//added by me
void Graph::infectNode(int nodeInd){
    this->infectedQueue.push_back(nodeInd);
    this->infectedVertices[nodeInd]=true;
}
bool Graph::isInfected(int nodeInd){
    return infectedVertices[nodeInd];
}
 bool Graph::getIsInfected(int node) const{
    return this->infectedVertices[node];
}
const std::vector<std::vector<int>> &Graph::getEdges() const{
    return this->edges;
}
const std::vector<bool> &Graph::getInfectedVertices() const{
    return this->infectedVertices;
}
const vector<int> &Graph::getInfectedQueue() const{
    return this->infectedQueue;
}
void Graph::setEdges(int column, int row,int newVal){
    this->edges[column][row] = newVal;
}
void Graph::popInfectedQueue(){
    this->infectedQueue.erase(this->infectedQueue.begin());
}



