//
// Created by spl211 on 17/11/2020.
//

#include "../include/Session.h"
#include "../include/Agent.h"
#include "../include/json.hpp"
#include <fstream>
#include <utility>
#define JSON_PATH "output.json"

using namespace std;
using json = nlohmann::json;

Session::Session(const std::string& path):g({}),treeType(),agents(),currCycle(0),virusNum(0),countIsFinished(0),isFinished(),carriers(){
    std::ifstream input(path);
    nlohmann:: json inputSession=nlohmann:: json::parse(input);
    std::vector<std::vector<int>> sessionGraph =inputSession.at("graph");
    setGraph(Graph(sessionGraph));
    std::vector<std::pair<string,int>> sessionAgents=inputSession.at("agents");
    std::vector<bool>temp(g.getEdges().size(),false);
    this->isFinished = temp;
    this->carriers =temp;
    int j=sessionAgents.size();
    for(int i = 0; i<j; i++){
        if (sessionAgents[i].first == "V"){
            Agent* virus = new Virus(sessionAgents[i].second);
            agents.push_back(virus);

        }
        else{
            Agent* CT=new ContactTracer();
            agents.push_back(CT);
        }
    }
    if (inputSession.at("tree") == "M"){
        this->treeType = MaxRank;
    }
    if (inputSession.at("tree") == "C"){
        this->treeType = Cycle;
    }
    if (inputSession.at("tree") == "R"){
        this->treeType = Root;
    }

}

Session::~Session(){//destructor
    this->clear();
}

void Session::clear(){
    for(Agent* a:this->agents){
        delete a;
    }
}

//copy constructor
Session::Session(const Session &other):g(other.getGraph()),
                                       treeType(other.getTreeType()),
                                       agents(other.agents),
                                       currCycle(other.currCycle),
                                       virusNum(other.getVirusNum()),
                                       countIsFinished(0),
                                       isFinished(other.getIsFinished()),
                                       carriers(other.getCarriers()){
    int a=other.agents.size();
    for(int i=0;i<a;i++){
        agents.push_back(other.getAgents()[i]->clone());
    }
}

Session & Session:: operator=(const Session &other) {//assignment operator
    if (this != &other) {
        this->clear();
        for(Agent* a:other.getAgents()){
            this->agents.push_back(a->clone());
        }
        this->g = other.g;
        this->countIsFinished = other.countIsFinished;
        this->isFinished = other.isFinished;
        this->virusNum = other.virusNum;
        this->countIsFinished = other.countIsFinished;
        this->carriers = other.carriers;
        this->currCycle = other.currCycle;
        this->treeType = other.treeType;

    }
    return *this;
}

Session::Session( Session &&other) noexcept :g({}),treeType(),agents(),currCycle(),virusNum(),countIsFinished(),isFinished(),carriers(){//Move constructor
    std::vector<Agent*> copy=other.getAgents();
    int a=copy.size();
    for(int i=0;i<a;i++){
        Agent* agentPtr;
        agentPtr=copy[i];
        this->addAgent(*agentPtr);
    }
    other.setAgent();
    this->g = other.g;
    this->countIsFinished = other.countIsFinished;
    this->isFinished = other.isFinished;
    this->virusNum = other.virusNum;
    this->countIsFinished = other.countIsFinished;
    this->carriers = other.carriers;
    this->currCycle = other.currCycle;
    this->treeType = other.treeType;
}

Session& Session:: operator=( Session&& other)noexcept //move assignment operator
{
    for(Agent* a:this->agents){
        delete a;
    }
    int a=other.getAgents().size();
    for(int i=0;i<a;i++){
        Agent*  agentPtr;
        agentPtr=other.getAgents()[i];
        this->addAgent(*agentPtr);
        other.getAgents()[i]= nullptr;
    }
    this->g = other.g;
    this->countIsFinished = other.countIsFinished;
    this->isFinished = other.isFinished;
    this->virusNum = other.virusNum;
    this->countIsFinished = other.countIsFinished;
    this->carriers = other.carriers;
    this->currCycle = other.currCycle;
    this->treeType = other.treeType;
    return *this;
}

void Session::simulate(){
    bool init=true;
    while (init || countIsFinished <this->virusNum){
        init=false;
        int a=this->agents.size();
        for (int i = 0; i < a; i++) {
            agents[i]->act(*this);
        }
        currCycle++;
    }
    nlohmann::json output;
    output["graph"]=g.getEdges();
    std::vector<int>temp1={};
    int j=this->getIsFinished().size();
    for(int i=0;i<j;i++){
        if(this->getIsFinished()[i]) {
            temp1.push_back(i);
        }
    }
    output["infected"]=temp1;
    std::ofstream sessionOutput("./output.json");
    sessionOutput << output ;
}

void Session::addAgent(const Agent& agent) {
    this->agents.push_back(agent.clone());
}

void Session:: enqueueInfected(int node){ //add virus to queue and update the infected list
    this->g.infectNode(node); //get as sa const or not.
}

int Session::dequeueInfected(){
    if(!this->getGraph().getInfectedQueue().empty()){
        int dequeue=getGraph().getInfectedQueue()[0];
        this->g.popInfectedQueue();
        return dequeue;
    }
    else return -1;
}


const Graph &Session::getGraph() const{
    return g;
}

std::vector<Agent*> Session::getAgents() const{
    return this->agents;
}

TreeType Session::getTreeType()const {
    return treeType;
}

const std::vector<bool> &Session::getCarriers() const {
    return this->carriers;
}

const std::vector<bool> &Session::getIsFinished()const{
    return this->isFinished;
}

int Session::getVirusNum()const {
    return this->virusNum;
}

int Session::getCurrCycle()const{
    return this->currCycle;
}

void Session::setGraph(const Graph& graph){
    this->g = graph;
}

void Session::setGraphEdges(int column,int row,int newVal){
    this->g.setEdges(column,row,newVal);
}

void Session::setAgent(){
    for(auto & agent:this->agents){
        agent=nullptr;
    }
}

void Session::setIsFinished(int node,bool finished){
    this->isFinished[node] = finished;
}

void Session::setCarrier(int node){
    this->carriers[node]=true;
}

void Session::addCountIsFinished() {
    this->countIsFinished++;
}

void Session::addVirusNUm(){
    this->virusNum++;
}

