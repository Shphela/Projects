//
// Created by spl211 on 17/11/2020.
//
#include "../include/Tree.h"
#include "../include/Session.h"

Tree::Tree(int rootLabel):node(rootLabel),children() {}

Tree::~Tree(){//destructor
   this->clear();
}

void Tree:: clear(){
    for(Tree* t:this->children){
        delete t;
    }
    children.clear();
}


Tree::Tree(const Tree & other):node(other.getNode()),children(other.getChildren()){//copy constructor
    for(Tree* t:other.getChildren()){
        this->children.push_back(t->clone());
    }
}
Tree & Tree:: operator=(const Tree &other){//assignment operator
    if(this!=&other){
        this->clear();
        for(Tree* t:other.getChildren()){
            this->children.push_back(t->clone());
        }
        this->node = other.getNode();

    }

    return *this;
}

Tree::Tree( Tree &&other)noexcept:node(),children() //Move constructor
{
    std::vector<Tree*> copy=other.getChildren();
    this->node = other.getNode();
    int j=copy.size();
    for(int i=0;i<j;i++){
        Tree* treePtr;
        treePtr=copy[i];
        this->children.push_back(treePtr);
    }
    other.setChild();
}

Tree& Tree:: operator=( Tree&& other)noexcept//move assignment operator
{
    this->clear();
    int j=other.getChildren().size();
    for(int i=0;i<j;i++){
        Tree* treePtr;
        treePtr=other.getChildren()[i];
        this->children.push_back(treePtr);
        other.children[i]= nullptr;
    }
    return *this;
}



Tree* Tree::createTree(const Session& session, int rootLabel){
    if(session.getTreeType() == Cycle) {
        return new CycleTree(rootLabel, session.getCurrCycle());
    }
    if(session.getTreeType() == MaxRank) {
        return new MaxRankTree(rootLabel);
    }
    else{
        return new RootTree(rootLabel);
    }
}

void Tree::addChild(const Tree& child){
    Tree* copy=child.clone();
    children.push_back(copy);
}
void Tree::setChild() {
    for(auto & child:this->children){
        child=nullptr;
    }
}
std::vector<Tree*> Tree::getChildren() const{
    return this->children;
}
int Tree::getNode() const {
    return this->node;
}


CycleTree::CycleTree(int rootLabel, int currCycle):Tree(rootLabel),currCycle(currCycle){}

int CycleTree::traceTree(){
    if(currCycle==0 || this->getChildren().empty()) {
        return this->getNode();
    }
    int c=1;
    Tree* node=this->getChildren()[0];
    while(c<currCycle && !node->getChildren().empty()){
        node=node->getChildren()[0];
        c++;
    }
    int val=node->getNode();
    node=nullptr;
    delete node;
    return val;
}

Tree* CycleTree:: clone() const{
    return new CycleTree (*this);
}

//MaxRankTree
MaxRankTree::MaxRankTree(int rootLabel):Tree(rootLabel){}

int MaxRankTree::traceTree() {
    if (this->getChildren().empty()){
        return this->getNode();
    }
    std::vector<Tree*> keep;
    keep.push_back(this);
    int node = this->getNode();
    int &val=node;
    int maxRank = 0;
    int maxDepth = 0;
    int currDepth = 0;
    while (!keep.empty()) {
        Tree *t = keep[0];
        keep.erase(keep.begin());
        int j = t->getChildren().size();
        if(maxRank < j){
            maxRank = j;
            maxDepth = currDepth;
            val = t->getNode();
        }
        if (maxRank == j){
            if (currDepth < maxDepth){ //iteration always start from left to right so left node always be first to know children size.
                maxRank = j;
                maxDepth = currDepth;
                val = t->getNode();
            }
        }
        if (!t->getChildren().empty()) {
            for (int i = 0; i < j; i++) {
                keep.push_back(t->getChildren()[i]);
            }
        }
        t = nullptr; //make sure not to scope delete t while points to val.
        delete t;
        currDepth++;
    }
    return val;
}

Tree* MaxRankTree:: clone() const{
    return new MaxRankTree (*this);
}
//RootTree
RootTree::RootTree(int rootLabel):Tree(rootLabel){}

int RootTree::traceTree(){
    return this->getNode();
}

Tree* RootTree:: clone() const{
    return new RootTree (*this);
}

Tree* Tree::BFS(int node,const Session& session){
    Tree* t=createTree(session,node);
    std::vector<bool> visited(session.getGraph().getEdges().size(),false);
    std::vector<Tree*> queue={t};
    while(!queue.empty()){
        Tree* parent=queue[0];
        visited[parent->getNode()]=true;
        int childCounter=0;
        queue.erase(queue.begin());
        int j=session.getGraph().getEdges().size();
        for(int i=0;i<j;i++){
            if(session.getGraph().getEdges()[parent->getNode()][i]==1 && !visited[i]) {
                visited[i] = true;
                Tree* child=createTree(session,i);
                parent->addChild(*child);
                delete child;
                queue.push_back(parent->getChildren()[childCounter]);
                childCounter++;
            }
        }
    }
    return t;
}

//////////////////////////////////////////////////////////////////////////////////////
//
// Created by spl211 on 10/11/2020.
//












//CycleTree

