//
// Created by spl211 on 17/11/2020.
//

#include "../include/Agent.h"
#include "../include/Session.h"
#include "../include/Tree.h"

Agent::Agent(){}
Agent::~Agent(){}
//Contact Tracer
ContactTracer::ContactTracer():Agent(){}
Agent* ContactTracer::clone()const {
    return new ContactTracer(*this);
}
void ContactTracer::act(Session& session) {
    int root = session.dequeueInfected();
    if (root != -1) {
        Tree *t = Tree::BFS(root,session);
        int sick = t->traceTree();
        int j=session.getGraph().getEdges().size();
        for (int i=0;i<j;i++) {
            if(session.getGraph().getEdges()[sick][i] == 1) {
                session.setGraphEdges(sick, i, 0);
                session.setGraphEdges(i, sick, 0);
            }
        }

        delete t;
    }
}
//void ContactTracer::clear() {}
//Virus
Virus::Virus(int nodeInt):Agent(),nodeInd(nodeInt){}

Agent* Virus::clone()const {
    return new Virus(*this);
}

void Virus:: act(Session& session){
    if (!session.getGraph().getInfectedVertices()[this->nodeInd]){
        session.enqueueInfected(this->nodeInd);
        session.addVirusNUm();
    }
    if (!(session.getIsFinished()[this->nodeInd])) {
            bool found = false;
            int j = session.getGraph().getEdges()[nodeInd].size();
            for (int i = 0; i < j && !found; i++) {
                if (session.getGraph().getEdges()[nodeInd][i] == 1 && !session.getGraph().getIsInfected(i) && !session.getCarriers()[i]) {
                    session.addAgent(Virus(i));
                    session.setCarrier(i);
                    found = true;
                }
            }
            if (!found) {
                session.setIsFinished(nodeInd, true);
                session.addCountIsFinished();
            }
        }
}
