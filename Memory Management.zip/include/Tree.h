//
// Created by spl211 on 17/11/2020.
//

#ifndef untitled2_TREE_H
#define untitled2_TREE_H
#include <vector>
class Session;

class Tree{
public:
    Tree(int rootLabel);
    virtual ~Tree();//destructor
    void clear();
    Tree(const Tree &other);//copy constructor
    Tree & operator=(const Tree &other);//assignment operator
    Tree( Tree&&other)noexcept;//Move constructor
    Tree& operator=(Tree&&other)noexcept;//move assignment operator
    void addChild(const Tree& child);
    void setChild();
    static Tree* createTree(const Session& session, int rootLabel);
    virtual Tree* clone() const=0;
    virtual int traceTree()=0;
    std::vector<Tree*> getChildren() const;
    int getNode() const;
    static Tree* BFS(int node,const Session& session);

private:
    int node;
    std::vector<Tree*> children;
};

class CycleTree: public Tree{
public:
    CycleTree(int rootLabel, int currCycle);
    virtual int traceTree();
    virtual Tree* clone() const;
private:
    int currCycle;
};

class MaxRankTree: public Tree{
public:
    MaxRankTree(int rootLabel);
    virtual int traceTree();
    virtual Tree* clone() const;
};

class RootTree: public Tree{
public:
    RootTree(int rootLabel);
    virtual int traceTree();
    virtual Tree* clone() const;
};


#endif //ASSIGNMENT1NEW_TREE_H

