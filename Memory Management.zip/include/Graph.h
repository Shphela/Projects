//
// Created by spl211 on 17/11/2020.
//

#ifndef untitled2_GRAPH_H
#define untitled2_GRAPH_H
#include <vector>
#include <string>

using namespace std;

class Graph{
public:
    //Graph();
    Graph(std::vector<std::vector<int>> matrix);
    void infectNode(int nodeInd);
    bool isInfected(int nodeInd);
    bool getIsInfected(int node) const;
    const std::vector<std::vector<int>> &getEdges() const;
    const std::vector<bool> &getInfectedVertices() const;
    const std::vector<int> &getInfectedQueue() const;
    void popInfectedQueue();
    void setEdges(int column,int row,int newVal);
private:
    std::vector<std::vector<int>> edges;
    std::vector<bool> infectedVertices; //List of all infected vertices in the graph
    std::vector<int> infectedQueue;

};




#endif //ASSIGNMENT1NEW_GRAPH_H