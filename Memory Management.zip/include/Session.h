//
// Created by spl211 on 17/11/2020.
//

#ifndef untitled2_SESSION_H
#define untitled2_SESSION_H


#include <vector>
#include <string>
#include "Graph.h"

class Agent;

enum TreeType{
    Cycle,
    MaxRank,
    Root
};

class Session {
public:
    Session(const std::string &path);

    ~Session();//destructor

    void clear();

    Session(const Session &other);//copy constructor

    Session &operator=(const Session &other);//assignment operator

    Session( Session &&other) noexcept;//Move constructor

    Session &operator=(Session &&other)noexcept;//move assignment operator

    void simulate();

    void addAgent(const Agent &agent);

    void enqueueInfected(int node);

    int dequeueInfected();

    const Graph &getGraph() const;

    std::vector<Agent *> getAgents() const;

    TreeType getTreeType() const;

    const std::vector<bool> &getCarriers() const;

    const std::vector<bool> &getIsFinished() const;

    int getVirusNum ()const;

    int getCurrCycle() const;

    void setGraph(const Graph &graph);

    void setGraphEdges(int column,int row,int newVal);

    void setAgent();

    void setIsFinished(int node,bool finished);

    void setCarrier(int node);

    void addCountIsFinished();

    void addVirusNUm();
private:
    Graph g;
    TreeType treeType;
    std::vector<Agent *> agents;
    //added by me
    int currCycle;
    int virusNum; //counter for number of active viruses
    int countIsFinished; // count number of viruses nodes that can't infect
    std::vector<bool> isFinished; //for each node, if node can't infect his index val is true.
    std::vector<bool> carriers; // use to check who are the carriers that added as Virus agent in current cycle
};

#endif //untitled2_SESSION_H