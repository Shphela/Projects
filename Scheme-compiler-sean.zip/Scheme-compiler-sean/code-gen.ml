#use "semantic-analyser.ml";;

(* This module is here for you convenience only!
   You are not required to use it.
   you are allowed to change it. *)
module type CODE_GEN = sig
  (* This signature assumes the structure of the constants table is
     a list of key-value pairs:
     - The keys are constant values (Sexpr(x) or Void)
     - The values are pairs of:
       * the offset from the base const_table address in bytes; and
       * a string containing the byte representation (or a sequence of nasm macros)
         of the constant value
     For example: [(Sexpr(Nil), (1, "T_NIL"))]
   *)
  val make_consts_tbl : expr' list -> (sexpr * (int * string)) list

  (* This signature assumes the structure of the fvars table is
     a list of key-value pairs:
     - The keys are the fvar names as strings
     - The values are the offsets from the base fvars_table address in bytes
     For example: [("boolean?", 0)]
   *)  
  val make_fvars_tbl : expr' list -> (string * int) list

  (* If you change the types of the constants and fvars tables, you will have to update
     this signature to match: The first argument is the constants table type, the second 
     argument is the fvars table type, and the third is an expr' that has been annotated 
     by the semantic analyser.
   *)
  val generate : (sexpr * (int * string)) list -> (string * int) list -> expr' -> string
end;;

module Code_Gen : CODE_GEN = struct

  let rec expand_constant const = match const with
   | ScmConst'(ScmSymbol(sym)) -> ScmString(sym) :: [ScmSymbol(sym)]
   | ScmConst'(ScmPair(car,cdr)) -> ((expand_constant (ScmConst'(car))) @ (expand_constant (ScmConst'(cdr)))) @ [ScmPair(car,cdr)]
   | ScmConst'(ScmVector(sexprs)) -> let expanded = List.map (fun sexpr -> expand_constant (ScmConst'(sexpr))) sexprs in
                                     List.flatten expanded @ [(ScmVector(sexprs))]
   | ScmConst'(sexpr) -> [sexpr]
   | _ -> raise X_this_should_not_happen

  let rec member element lst = match lst with
   | [] -> false
   | hd :: tl -> if (hd = element) then true else member element tl

  let remove_duplicates lst =
   let rec remove list reduced = (match list with
    | [] -> reduced
    | hd :: tl -> if (member hd reduced)
                  then remove tl reduced
                  else remove tl (hd :: reduced)) in
    List.rev (remove lst [])

  let get_offset = (fun (_,(offset,_)) -> offset)

  let get_key = (fun (key,(_,_)) -> key)

  let rec get_table_address const table = match table with
    | [] -> raise X_this_should_not_happen
    | const_tuple :: const_tuples -> if ((get_key const_tuple) = const)
                  then (Printf.sprintf "const_tbl+%d"  (get_offset const_tuple) )
                  else get_table_address const const_tuples

  let asmcode const table = match const with
   | ScmVoid -> "MAKE_VOID"
   | ScmNil -> "MAKE_NIL"
   | ScmChar(c) -> Printf.sprintf "MAKE_LITERAL_CHAR(\'%c\')" c
   | ScmBoolean(b) -> Printf.sprintf "MAKE_BOOL(%d)" (if b then 1 else 0)
   | ScmNumber(r) -> (match r with
                      | ScmRational(d,n) -> Printf.sprintf "MAKE_LITERAL_RATIONAL(%d,%d)"  d n
                      | ScmReal(float) -> Printf.sprintf "MAKE_LITERAL_REAL(%f)" float)
   | ScmString(str) -> Printf.sprintf "MAKE_LITERAL_STRING \"%s\"" str
   | ScmSymbol(sym) -> Printf.sprintf "MAKE_LITERAL_SYMBOL (%s)" (get_table_address (ScmString(sym)) table)
   | ScmVector(sexprs) -> let addresses = List.map (fun sexpr -> get_table_address sexpr table) sexprs in
                          let last_addrss = List.hd (List.rev addresses) in
                          let all_but_last = List.rev (List.tl (List.rev addresses)) in
                          let concatenated_addresses = List.fold_right (fun curr acc -> curr ^ "," ^ acc) all_but_last last_addrss in
                          Printf.sprintf "MAKE_LITERAL_VECTOR %s"  (concatenated_addresses)
   | ScmPair(car,cdr) -> Printf.sprintf "MAKE_LITERAL_PAIR(%s,%s)" (get_table_address car table) (get_table_address cdr table)

  let rec get_constant_size const = match const with
   | ScmVoid -> 1
   | ScmNil -> 1
   | ScmChar(c) -> 2
   | ScmBoolean(b) -> 2
   | ScmNumber(r) ->( match r with
                     | ScmRational(num,den) -> 1 + 8 + 8
                     | _ -> 1 + 8)
   | ScmString(str) -> 1 + 8 + (String.length str)
   | ScmSymbol(str) -> 1 + 8
   | ScmVector(sexprs) -> 1 + 8 + 8 * (List.length sexprs)
   | ScmPair(car,cdr) -> 1 + 8 + 8
   
  let make_consts_tbl asts = 
  let rec find_constants ast acc = match ast with 
   | ScmConst'(sexpr) -> acc @ (expand_constant (ScmConst'(sexpr)))
   | ScmVar'(v) -> acc
   | ScmBox'(b) -> acc
   | ScmBoxGet'(v) -> acc
   | ScmBoxSet'(v,expr) -> find_constants expr acc
   | ScmIf'(test,dit,dif) -> let constants_test = find_constants test acc in
                             let constants_dit = find_constants dit constants_test in
                             let constants_if = find_constants dif constants_dit in
                             constants_if
   | ScmSeq'(exprs) -> List.fold_left (fun acc curr -> find_constants curr acc) acc exprs
   | ScmSet'(v,expr) -> find_constants expr acc
   | ScmDef'(v,expr) -> find_constants expr acc
   | ScmOr'(exprs) -> List.fold_left (fun acc curr -> find_constants curr acc) acc exprs
   | ScmLambdaSimple'(params,body) -> find_constants body acc
   | ScmLambdaOpt'(params,opt,body) -> find_constants body acc
   | ScmApplic'(proc,args) -> List.fold_left (fun acc curr -> find_constants curr acc) acc (proc :: args)
   | ScmApplicTP'(proc,args) -> List.fold_left (fun acc curr -> find_constants curr acc) acc (proc :: args) in

   let constancs_in_asts = List.fold_right (fun curr acc -> (find_constants curr []) @ acc) asts [] in
   let extended_table = [ScmNil;ScmVoid;ScmBoolean true;ScmBoolean false] @ constancs_in_asts in
   let no_duplicates = remove_duplicates extended_table in
   
   let rec build_table_tuples consts consts_table = (match consts with
    | [] -> consts_table
    | c1 :: cs -> if (consts_table = []) 
                  then (build_table_tuples cs [(c1,(0,asmcode c1 consts_table))])
                  else (build_table_tuples cs  (((c1,((get_offset (List.hd consts_table)) + (get_constant_size (get_key (List.hd consts_table))),asmcode c1 consts_table))) :: consts_table))) in
    let reversed_table = build_table_tuples no_duplicates [] in
    List.rev reversed_table;;

  let index_of_prev fvars_tbl = match fvars_tbl with
   | [] -> -1
   | hd :: tl -> ((fun (_,offset) -> offset) hd)
   
  let make_fvars_tbl asts = 
   let rec find_fvars ast acc = match ast with
    | ScmConst'(sexpr) -> acc
    | ScmVar'(v) -> (match v with
                     | VarFree(fvar) -> acc @ [fvar]  
                     | _ -> acc)
    | ScmBox'(b) -> acc
    | ScmBoxGet'(v) -> acc
    | ScmBoxSet'(v,expr) -> find_fvars expr acc
    | ScmIf'(test,dit,dif) -> let fvars_test = find_fvars test acc in
                              let fvars_dit = find_fvars dit fvars_test in
                              let fvars_if = find_fvars dif fvars_dit in
                              fvars_if
    | ScmSeq'(exprs) -> List.fold_left (fun acc curr -> find_fvars curr acc) acc exprs
    | ScmSet'(v,expr) -> let add_set_fvar = find_fvars (ScmVar'(v)) acc in  
                         find_fvars expr add_set_fvar
    | ScmDef'(v,expr) -> let add_def_fvar = find_fvars (ScmVar'(v)) acc in
                         find_fvars expr add_def_fvar
    | ScmOr'(exprs) -> List.fold_left (fun acc curr -> find_fvars curr acc) acc exprs
    | ScmLambdaSimple'(params,body) -> find_fvars body acc
    | ScmLambdaOpt'(params,opt,body) -> find_fvars body acc
    | ScmApplic'(proc,args) -> List.fold_left (fun acc curr -> find_fvars curr acc) acc (proc :: args)
    | ScmApplicTP'(proc,args) -> List.fold_left (fun acc curr -> find_fvars curr acc) acc (proc :: args) in

    let fvars_in_asts = List.fold_right (fun curr acc -> (find_fvars curr []) @ acc) asts [] in
    let fvars_in_asts = ["boolean?";"flonum?";"rational?";"pair?";"null?";"char?";"string?";"procedure?";"symbol?";
    "string-length";"string-ref";"string-set!";"make-string";"symbol->string";"char->integer";"integer->char";"exact->inexact";
    "eq?";"+";"*";"/";"=";"<";"numerator";"denominator";"gcd";"cons";"car";"cdr";"set-car!";"set-cdr!";"binary-apply";] @ fvars_in_asts in
    let no_duplicates = remove_duplicates fvars_in_asts in

    let rec build_table_tuples fvars freevars_table = (match fvars with
     | [] -> freevars_table
     | fvar :: fvars' -> build_table_tuples fvars' ((fvar,1+(index_of_prev freevars_table)) :: freevars_table)) in
    let fvar_tbl = build_table_tuples no_duplicates [] in
    List.rev fvar_tbl;;

  let rec make_args_code argsInstructions = match argsInstructions with
   | [] -> ""
   | [code] -> code ^ "\npush rax"
   | _ ->   (List.fold_right (fun acc curr ->Printf.sprintf "
%s                            
push rax
%s
            " acc curr ) (List.rev(List.tl argsInstructions)) (List.hd argsInstructions)) ^ "\npush rax"

  let label_counter = ref 0 
  let generate consts fvars e = 
  
  let generate_const  consts c = 
      let const_row = List.find (fun (const,(_,_)) -> sexpr_eq const c) consts in
      let offset = (fun (_, (off, _)) -> off) const_row in
      Printf.sprintf "
mov rax, const_tbl+%d" offset 
  in
  let generate_get_ScmVar fvars var' = match var' with 
      | VarFree(name) -> 
        let fvar_row = List.find (fun (varName,_)-> String.equal name varName) fvars in
        let index = (fun (_,index)->index) fvar_row in 
        Printf.sprintf "
mov rax, FVAR(%d)" index
      | VarParam(_,minor) -> 
        Printf.sprintf "
mov rax, PVAR(%d)" minor
      | VarBound(_,major,minor)-> 
        Printf.sprintf "
mov rax, qword [rbp + 8*2] 
mov rax, VECTOR_REF(rax,%d) 
mov rax, VECTOR_REF(rax,%d)" major minor   
                        
                        
  in
  let generate_set_ScmVar var' expr' consts fvars assumedGeneratedExpr' = match var' with
      | VarFree(name) -> 
        let fvar_row = List.find (fun (varName,_)-> String.equal name varName) fvars in
        let index = (fun (_,index)->index) fvar_row in 
        Printf.sprintf "
%s 
mov FVAR(%d), rax
mov rax, SOB_VOID_ADDRESS" assumedGeneratedExpr' index               
                        
      | VarParam(_,minor) -> 
        Printf.sprintf "
%s 
mov PVAR(%d), rax
mov rax, SOB_VOID_ADDRESS" assumedGeneratedExpr' minor
      | VarBound(_,major,minor)-> 
        Printf.sprintf "
%s
push rbx 
mov rbx, qword [rbp + 8*2]
mov rbx, VECTOR_REF(rbx,%d)
mov VECTOR_REF(rbx,%d), rax
pop rbx 
mov rax, SOB_VOID_ADDRESS" assumedGeneratedExpr' major minor
  in 
                        
  let rec run consts fvars e label_counter closure_or_applic inside_applic = match e with 
    | ScmConst'(c) -> generate_const consts c (*Checked *)
    | ScmVar'(var') -> generate_get_ScmVar fvars var'(*VarFree Checked *)
    | ScmSet'(var',expr')-> let assumedGeneratedExpr' = run consts fvars expr' label_counter closure_or_applic inside_applic in (* Checked *)
                            generate_set_ScmVar var' expr' consts fvars assumedGeneratedExpr'
    | ScmSeq'(exprList) -> let instructionSeq = List.map (fun expr' -> run consts fvars expr' label_counter closure_or_applic inside_applic)  exprList  in (* Checked *)
                            (List.fold_left (fun acc curr ->Printf.sprintf "%s
%s" acc curr ) "" instructionSeq)
    | ScmOr'(exprList) -> let instructionDisj = List.map (fun expr' -> run consts fvars expr' label_counter closure_or_applic inside_applic) exprList in (* Checked *)
                          let inc_label_counter = (fun ()-> !label_counter ) (label_counter:= !label_counter +1) in 
                          let untrimmedString = List.fold_left (fun acc curr ->Printf.sprintf "%s
%s
cmp rax, SOB_FALSE_ADDRESS
jne Lexit%d" acc curr inc_label_counter ) "" instructionDisj in
                          (String.sub untrimmedString 0 ((String.length untrimmedString)-39)) ^ Printf.sprintf "\nLexit%d:" inc_label_counter 
    | ScmIf'(test,dit,dif) -> let generatedTest = run consts fvars test label_counter closure_or_applic inside_applic in (* Checked *)
                              let generatedDit =  run consts fvars dit label_counter closure_or_applic inside_applic in  
                              let generatedDif =  run consts fvars dif label_counter closure_or_applic inside_applic in
                              let inc_label_counter = (fun ()-> !label_counter ) (label_counter:= !label_counter +1) in 
                              Printf.sprintf "
%s
cmp rax, SOB_TRUE_ADDRESS
jne Lelse%d
%s
jmp Lexit%d
Lelse%d:
%s
Lexit%d:" generatedTest  inc_label_counter generatedDit inc_label_counter inc_label_counter generatedDif inc_label_counter
    | ScmBox'(var') -> Printf.sprintf "
%s
push rbx
MALLOC rbx, 8 
mov qword[rbx], rax
mov rax, rbx
pop rbx" (generate_get_ScmVar fvars var')

    | ScmBoxGet'(var') -> let generatedStr = generate_get_ScmVar fvars var' in
                         Printf.sprintf "
%s
mov rax, qword [rax]" generatedStr
    | ScmBoxSet'(var',expr')-> let generatedArr = [(generate_get_ScmVar fvars var');(run consts fvars expr' label_counter closure_or_applic inside_applic)]in
                               Printf.sprintf "
%s
push rax
%s
pop qword[rax]
mov rax, SOB_VOID_ADDRESS" (List.hd (List.tl generatedArr )) (List.hd generatedArr)
   | ScmLambdaSimple'(params,body) ->  (* Checked *)
   let inc_label_counter = (fun ()-> !label_counter ) (label_counter:= !label_counter +1) in 
   let generateBody = run consts fvars body label_counter closure_or_applic inside_applic in
   Printf.sprintf "
MAKE_EXTENV rax,qword[rbp+ WORD_SIZE*2],qword[rbp+3*WORD_SIZE] ;Create ExtEnv(address in rax) 
push rbx 
MAKE_CLOSURE(rbx,rax,Lcode%d) ;Allocate closure object(address in rbx)
mov rax,rbx ;(rax holds the Closure's address)
pop rbx
jmp Lcont%d
Lcode%d:
push rbp
mov rbp, rsp
%s
LEAVE
ret
Lcont%d:"  inc_label_counter inc_label_counter inc_label_counter generateBody  inc_label_counter 
   | ScmApplic'(proc,args)-> let inc_label_counter = (fun ()-> !label_counter ) (label_counter:= !label_counter +1) in (* Checked *)
                            let argsInstructions = List.map (fun expr'-> run consts fvars expr' label_counter 3 "qword[rsp+3*WORD_SIZE]") args in
                            let pushArgsInstruction = make_args_code argsInstructions in 
                            let numOfArgs = "
push " ^ string_of_int(List.length args) in
                            let generatedProc = run consts fvars proc label_counter 1 "qword[rbp+3*WORD_SIZE]" in 
                            let closureVerification =Printf.sprintf "
cmp byte[rax], T_CLOSURE
jz closureVerified%d ; If the proc is closure, then we move on, else we divide by 0 to raise exception
mov r10, 0
div r10
closureVerified%d:" inc_label_counter inc_label_counter in 
                            let pushEnv = "
push ENV(rax)" in
                            let callCode = "
call BODY(rax)"in
                            let aftermath ="
add rsp , 8*1 ; pop env
pop rbx ; pop arg count
lea rsp , [rsp + 8*(1+rbx)];pop args + magic"  in 
"
push 0;pushing magic normal applic" ^ pushArgsInstruction ^ numOfArgs ^ generatedProc ^ closureVerification ^ pushEnv ^callCode^ aftermath 
                            
    | ScmLambdaOpt'(params,opt,body)-> let inc_label_counter = (fun ()-> !label_counter ) (label_counter:= !label_counter +1) in 
    let generateBody = run consts fvars body label_counter closure_or_applic inside_applic in 
   Printf.sprintf "
MAKE_EXTENV rax,qword[rbp+ WORD_SIZE*2],qword[rbp+3*WORD_SIZE] ;Create ExtEnv(address in rax)
push rbx
MAKE_CLOSURE(rbx,rax,Lcode%d);Allocate closure object(address in rbx)
mov rax,rbx ;(rax holds the Closure's address)
pop rbx 
jmp Lcont%d
Lcode%d:
push rbp
mov rbp,rsp
adj%d:
ADJUST_STACK_OPT_ARGS %s,qword[rbp+WORD_SIZE*3]
pop rbp 

push rbp
mov rbp, rsp
%s
mov rsp,rbp 
pop rbp
ret
Lcont%d:"  inc_label_counter inc_label_counter inc_label_counter inc_label_counter  (string_of_int(List.length params)) generateBody  inc_label_counter 
    | ScmApplicTP'(proc,args)-> let inc_label_counter = (fun ()-> !label_counter ) (label_counter:= !label_counter +1) in (*Checked *)
                            let argsInstructions = List.map (fun expr'-> run consts fvars expr' label_counter 3 "qword[rsp+3*WORD_SIZE]")  args  in
                            let pushArgsInstruction = make_args_code argsInstructions in 
                            let numOfArgs = "
push " ^ string_of_int(List.length args) in
                            let generatedProc = run consts fvars proc label_counter 1 "qword[rbp+3*WORD_SIZE]" in 
                            let closureVerification =Printf.sprintf "
cmp byte[rax], T_CLOSURE
jz closureVerified%d ; If the proc is closure, then we move on, else we divide by 0 to raise exception
mov r10, 0
div r10
closureVerified%d:" inc_label_counter inc_label_counter in 
                            let pushEnv = "
push ENV(rax)" in
                            let pushOldRetAddr = "
push qword [rbp + WORD_SIZE*1]; old ret addr" in 
                            let size_old_frame = "
push r10 ; save                             
mov r10, qword[rbp+WORD_SIZE*3];update" in
                            let pushrbp = "
push qword[rbp]" in
                            let frameShift = Printf.sprintf "
SHIFT_FRAME %d" ((List.length args)+6) in 
                            let restore_rbp = "                           
pop rbp" in
                            let fix_rsp =  "
lea rsp,[rsp+WORD_SIZE*(r10+4)]
pop r10
pop r10"  in
                            let jmpCode = "
 
jmp BODY(rax)"    in 
"push 0;pushing magic applic TP" ^ pushArgsInstruction ^ numOfArgs ^ generatedProc ^ closureVerification ^ pushEnv ^ 
 pushOldRetAddr ^ size_old_frame ^ pushrbp  ^ frameShift ^ restore_rbp ^ fix_rsp ^ jmpCode
    | ScmDef'(variable,value) -> let assumedGeneratedExpr' = run consts fvars value label_counter closure_or_applic inside_applic in (* Checked*)
    (generate_set_ScmVar variable value consts fvars assumedGeneratedExpr') 
    in  
    run consts fvars  e label_counter 4 "qword[rsp+3*WORD_SIZE]"
end;;






