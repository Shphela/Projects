(* semantic-analyser.ml
 * The semantic analysis phase of the compiler
 *
 * Programmer: Mayer Goldberg, 2021
 *)

#use "tag-parser.ml";;

exception X_not_yet_implemented;;
exception X_this_should_not_happen;;

type var' = 
  | VarFree of string
  | VarParam of string * int
  | VarBound of string * int * int;;

type expr' =
  | ScmConst' of sexpr
  | ScmVar' of var'
  | ScmBox' of var'
  | ScmBoxGet' of var'
  | ScmBoxSet' of var' * expr'
  | ScmIf' of expr' * expr' * expr'
  | ScmSeq' of expr' list
  | ScmSet' of var' * expr'
  | ScmDef' of var' * expr'
  | ScmOr' of expr' list
  | ScmLambdaSimple' of string list * expr'
  | ScmLambdaOpt' of string list * string * expr'
  | ScmApplic' of expr' * (expr' list)
  | ScmApplicTP' of expr' * (expr' list);;

type read =
  | ParamRead of (expr' list)
  | BoundRead of (expr' list);;

let var_eq v1 v2 =
match v1, v2 with
  | VarFree (name1), VarFree (name2) -> String.equal name1 name2
  | VarBound (name1, major1, minor1), VarBound (name2, major2, minor2) ->
    major1 = major2 && minor1 = minor2 && (String.equal name1 name2)
  | VarParam (name1, index1), VarParam (name2, index2) ->
       index1 = index2 && (String.equal name1 name2)
  | _ -> false

let rec expr'_eq e1 e2 =
  match e1, e2 with
  | ScmConst' (sexpr1), ScmConst' (sexpr2) -> sexpr_eq sexpr1 sexpr2
  | ScmVar' (var1), ScmVar' (var2) -> var_eq var1 var2
  | ScmIf' (test1, dit1, dif1), ScmIf' (test2, dit2, dif2) -> (expr'_eq test1 test2) &&
                                            (expr'_eq dit1 dit2) &&
                                              (expr'_eq dif1 dif2)
  | (ScmSeq' (exprs1), ScmSeq' (exprs2) | ScmOr' (exprs1), ScmOr' (exprs2)) ->
        List.for_all2 expr'_eq exprs1 exprs2
  | (ScmSet' (var1, val1), ScmSet' (var2, val2) | ScmDef' (var1, val1), ScmDef' (var2, val2)) ->
        (var_eq var1 var2) && (expr'_eq val1 val2)
  | ScmLambdaSimple' (vars1, body1), ScmLambdaSimple' (vars2, body2) ->
     (List.for_all2 String.equal vars1 vars2) && (expr'_eq body1 body2)
  | ScmLambdaOpt' (vars1, var1, body1), ScmLambdaOpt' (vars2, var2, body2) ->
     (String.equal var1 var2) &&
       (List.for_all2 String.equal vars1 vars2) && (expr'_eq body1 body2)
  | ScmApplic' (e1, args1), ScmApplic' (e2, args2) ->
     (expr'_eq e1 e2) && (List.for_all2 expr'_eq args1 args2)
  | ScmApplicTP' (e1, args1), ScmApplicTP' (e2, args2) ->
      (expr'_eq e1 e2) && (List.for_all2 expr'_eq args1 args2)
  | ScmBox' (v1), ScmBox' (v2) -> var_eq v1 v2
  | ScmBoxGet' (v1), ScmBoxGet' (v2) -> var_eq v1 v2
  | ScmBoxSet' (v1, e1), ScmBoxSet' (v2, e2) -> (var_eq v1 v2) && (expr'_eq e1 e2)
  | _ -> false;;


module type SEMANTIC_ANALYSIS = sig
  val annotate_lexical_addresses : expr -> expr'
  val annotate_tail_calls : expr' -> expr'
  val box_set : expr' -> expr'
  val run_semantics : expr -> expr'
  val find_reads : string->expr'->expr'->read list
end;; (* end of module type SEMANTIC_ANALYSIS *)

module Semantic_Analysis : SEMANTIC_ANALYSIS = struct

  let rec lookup_in_rib name = function
    | [] -> None
    | name' :: rib ->
       if name = name'
       then Some(0)
       else (match (lookup_in_rib name rib) with
             | None -> None
             | Some minor -> Some (minor + 1));;

  let rec lookup_in_env name = function
    | [] -> None
    | rib :: env ->
       (match (lookup_in_rib name rib) with
        | None ->
           (match (lookup_in_env name env) with
            | None -> None
            | Some(major, minor) -> Some(major + 1, minor))
        | Some minor -> Some(0, minor));;

  let tag_lexical_address_for_var name params env = 
    match (lookup_in_rib name params) with
    | None ->
       (match (lookup_in_env name env) with
        | None -> VarFree name
        | Some(major, minor) -> VarBound(name, major, minor))
    | Some minor -> VarParam(name, minor);;

  (* run this first! *)
  let annotate_lexical_addresses pe = 
   let rec run pe params env =
      match pe with 
      | ScmConst(sexpr) -> ScmConst' (sexpr)
      | ScmVar(varName) -> (match env with 
                          | [] ->  ScmVar'(tag_lexical_address_for_var varName params env)
                          | _ -> ScmVar'(tag_lexical_address_for_var varName params (List.tl env)) )
      | ScmIf(test,dit,dif) -> ScmIf'(run test params env, run dit params env, run dif params env )
      | ScmSeq(seq) -> ScmSeq'((List.map (fun expr -> (run expr params env))seq))
      | ScmSet(variable,value) -> (match variable,env with 
                              | ScmVar(varName),[] -> ScmSet'(tag_lexical_address_for_var varName params env,run value params env) 
                              | ScmVar(varName),_ -> ScmSet'(tag_lexical_address_for_var varName params (List.tl env),run value params env)  
                              | _,_ -> raise X_this_should_not_happen)
      | ScmDef(variable,value) -> (match variable with 
                              | ScmVar(varName) ->( match env with 
                                                  | [] -> ScmDef'(VarFree(varName),run value params env)
                                                  | _ -> ScmDef'(tag_lexical_address_for_var varName params (List.tl env),run value params env))
                              | _ -> raise X_this_should_not_happen )                       
      | ScmOr(conjunctions) -> ScmOr'((List.map (fun expr -> (run expr params env))conjunctions)) 
      | ScmLambdaSimple(paramsList,body) -> ( let extEnv = match env with 
                                            | [] ->[paramsList] 
                                            | _ -> List.append [paramsList] env in
                                 ScmLambdaSimple'(paramsList, run body paramsList extEnv))
      | ScmLambdaOpt(paramsList,rest,body) ->(let paramListOpt =  List.append paramsList [rest] in 
                                              let extEnv = match env with 
                                              | [] ->[paramListOpt] 
                                              | _ -> List.append [paramListOpt] env in
                                 ScmLambdaOpt'(paramsList,rest,run body  paramListOpt extEnv))
      | ScmApplic(op,args) -> ScmApplic'(run op params env, List.map (fun expr -> (run expr params env)) args)
   in 
   run pe [] [];;
   
  let rec rdc_rac s =
    match s with
    | [e] -> ([], e)
    | e :: s ->
       let (rdc, rac) = rdc_rac s
       in (e :: rdc, rac)
    | _ -> raise X_this_should_not_happen;;
  
  (* run this second! *)
  let annotate_tail_calls pe =
  (*let preprocessed_expr = match pe with
   | ScmApplic'(proc,args) -> ScmApplicTP'(proc,args)
   | _ -> pe in*)
   let rec run pe in_tail =
      match pe with 
      | ScmLambdaSimple'(paramsList,body) -> ScmLambdaSimple'(paramsList,run body true )
      | ScmLambdaOpt'(paramListOpt,rest,body) -> ScmLambdaOpt'(paramListOpt,rest,run body true)
      | ScmIf'(test,dit,dif) -> (match in_tail with 
                                | true -> ScmIf'(test,run dit true,run dif true)
                                | false -> ScmIf'(test,run dit false,run dif false))
      | ScmSeq'(seq) -> (let tuple = rdc_rac seq in 
                        match tuple,in_tail with 
                        | (rdc,rac),true -> ScmSeq'(List.append (List.map (fun expr' -> run expr' false) rdc) [(run rac true)])
                        | _ -> ScmSeq'(List.map (fun expr' -> run expr' false)seq))
      | ScmOr'(conjunctions) -> (let tuple = rdc_rac conjunctions in 
                                match tuple,in_tail with 
                                | (rdc,rac),true -> ScmOr'( List.append (List.map (fun expr' -> run expr' false) rdc) [(run rac true)])
                                | _ ->  ScmOr'(List.map (fun expr' -> run expr' false)conjunctions))
      | ScmSet'(variable,value) -> ScmSet'(variable, run value false)
      | ScmDef'(variable,value) -> ScmDef'(variable,run value false)
      | ScmApplic'(op,args) -> (match in_tail with 
                              | true -> ScmApplicTP'(run op false,List.map (fun expr' -> run expr' false )args)
                              | false -> ScmApplic'(run op false,List.map (fun expr' -> run expr' false )args)) 
      | _ -> pe 
   in 
   run pe false;;

  (* boxing *)

  let find_reads name enclosing_lambda expr = (* name isn't boxed yet,we don't box a name twice (parameter names are distince)*)
   let rec get_reads name enclosing_lambdas expr reads =
   let get_reads_from_list exprs = List.fold_left (fun current_reads e -> get_reads name enclosing_lambdas e current_reads) reads exprs in
   let get_reads_from_lambda parameters body = match (List.find_opt (fun param_name -> param_name = name) parameters) with
                                                | Some(param) -> reads
                                                | None -> get_reads name (expr::enclosing_lambdas) body reads in                                        
    match expr with
    | ScmConst'(sexpr) -> reads
    | ScmVar'(var') -> (match var' with
                          | VarFree(str) -> reads
                          | VarParam(str,minor) -> if str = name
                                                 then ParamRead(enclosing_lambdas) :: reads
                                                 else reads
                          | VarBound(str,major,minor) -> if str = name
                                                         then BoundRead(enclosing_lambdas) :: reads
                                                         else reads)
    | ScmBox'(v) -> reads
    | ScmBoxGet'(v) -> reads
    | ScmBoxSet'(v,value) -> get_reads name enclosing_lambdas value reads
    | ScmIf'(test,dit,dif) -> let test_reads = get_reads name enclosing_lambdas test reads in
                              let dit_reads = get_reads name enclosing_lambdas dit test_reads in
                              let if_reads = get_reads name enclosing_lambdas dif dit_reads in
                              if_reads
    | ScmSeq'(exprs) -> get_reads_from_list exprs
    | ScmSet'(var,value) -> get_reads name enclosing_lambdas value reads
    | ScmDef'(var,value) -> get_reads name enclosing_lambdas value reads
    | ScmOr'(exprs) -> get_reads_from_list exprs
    | ScmLambdaSimple'(parameters,body) -> get_reads_from_lambda parameters body
    | ScmLambdaOpt'(parameters,optional,body) -> get_reads_from_lambda (optional :: parameters) body
    | ScmApplic'(proc,args) -> get_reads_from_list (proc :: args)
    | ScmApplicTP'(proc,args) -> get_reads_from_list (proc :: args) in
    get_reads name [enclosing_lambda] expr [];;

  let rec get_param_reads = function
    | [] -> []
    | ParamRead(enclosing_lambdas) :: tl -> (enclosing_lambdas) :: (get_param_reads tl)
    | hd :: tl -> get_param_reads(tl)
  
  let rec get_bounds_reads = function
    | [] -> []
    | BoundRead(enclosing_lambdas) :: tl -> (enclosing_lambdas)::get_bounds_reads(tl)
    | hd :: tl -> get_bounds_reads(tl)
  
  let rec disjoint_ribs enclosing1 enclosing2 = match enclosing1,enclosing2 with
                                            | [],[] -> true
                                            | (lambda1::lambdas),[] -> true
                                            | [],(lambda1::lambdas) -> true
                                            | (lambda1::rest1),(lambda2::rest2) -> if lambda1 == lambda2 then false else ((disjoint_ribs rest1 rest2) && (disjoint_ribs enclosing1 rest2) && (disjoint_ribs rest1 enclosing2))
                                                                                                                                             
   let rec need_to_box_bound enclosing_lambdas bound_reads = match bound_reads with
                                                          | [] -> false
                                                          | (wrapping_lambdas)::reads ->if (disjoint_ribs enclosing_lambdas wrapping_lambdas)
                                                                                                    then true
                                                                                                    else need_to_box_bound enclosing_lambdas reads 
  let rec need_to_box expr parameter body =  (* add support for box exprs *)
   let reads = find_reads parameter expr body in
   let bound_reads = get_bounds_reads reads in
   let param_reads = get_param_reads reads in
   let rec need_to_box' parameter enclosing_lambdas expr_in_body =
   let need_boxing_list exprs = let found = (List.find_opt (need_to_box' parameter enclosing_lambdas) exprs) in
                                                                  (match found with
                                                                   | Some(expr) -> true
                                                                   | _ -> false) in
   let need_boxing_lambda params body' = (match (List.find_opt (fun param_name -> param_name = parameter) params) with
                                                                                      | Some(param) -> false
                                                                                      | None ->  need_to_box' parameter (expr_in_body::enclosing_lambdas) body') in
  
                                            match expr_in_body with
                                              | ScmConst'(sexpr) -> false
                                              | ScmVar'(var') -> false
                                              | ScmBox'(v) -> false
                                              | ScmBoxGet'(v) -> false
                                              | ScmBoxSet'(v,value) -> need_to_box' parameter enclosing_lambdas value
                                              | ScmIf'(test,dit,dif) -> (need_to_box' parameter enclosing_lambdas test) || (need_to_box' parameter enclosing_lambdas dit) || (need_to_box' parameter enclosing_lambdas dif)
                                              | ScmSeq'(exprs) -> need_boxing_list exprs
                                              | ScmSet'(var,value) -> (match var with 
                                                                       | VarFree(v) -> false
                                                                       | VarParam(v,minor) -> if v = parameter 
                                                                                              then (if bound_reads = [] 
                                                                                                    then false
                                                                                                    else true)
                                                                                              else (need_to_box' parameter enclosing_lambdas value)
                                                                       | VarBound(v,major,minor) -> if v = parameter
                                                                                                    then (if param_reads = []
                                                                                                          then (need_to_box_bound enclosing_lambdas bound_reads)
                                                                                                          else true)
                                                                                                    else (need_to_box' parameter enclosing_lambdas value))
                                              | ScmOr'(exprs) -> need_boxing_list exprs
                                              | ScmLambdaSimple'(params,body') -> need_boxing_lambda params body'
                                              | ScmLambdaOpt'(params,optional,body') -> need_boxing_lambda (optional::params) body'
                                              | ScmApplic'(proc,args) -> (need_to_box' parameter enclosing_lambdas proc) || (need_boxing_list args)
                                              | ScmApplicTP'(proc,args) -> (need_to_box' parameter enclosing_lambdas proc) || (need_boxing_list args)
                                              | _ -> raise X_this_should_not_happen in
                                              need_to_box' parameter [] body
  
  let rec box_parameter_in_body name body_expr = (* add support for box exprs *)
    match body_expr with
     | ScmConst'(const) -> body_expr
     | ScmVar'(v) -> (match v with
                      | VarParam(n,minor) -> if n = name then ScmBoxGet'(v) else body_expr
                      | VarBound(n,major,minor) -> if n = name then ScmBoxGet'(v) else body_expr
                      | _ -> body_expr)
     | ScmBox'(v) -> body_expr
     | ScmBoxGet'(v) -> body_expr
     | ScmBoxSet'(v,value) -> ScmBoxSet'(v,box_parameter_in_body name value)
     | ScmIf'(test,dit,dif) -> ScmIf'(box_parameter_in_body name test,box_parameter_in_body name dit,box_parameter_in_body name dif)
     | ScmSeq'(exprs) -> ScmSeq'(List.map (box_parameter_in_body name) exprs)
     | ScmSet'(v,value) -> (match v with
                      | VarParam(n,minor) -> if n = name then ScmBoxSet'(v,box_parameter_in_body name value) else ScmSet'(v,box_parameter_in_body name value)
                      | VarBound(n,major,minor) -> if n = name then ScmBoxSet'(v,box_parameter_in_body name value) else ScmSet'(v,box_parameter_in_body name value)
                      | _ -> ScmSet'(v,box_parameter_in_body name value))
     | ScmOr'(exprs) -> ScmOr'(List.map (box_parameter_in_body name) exprs)
     | ScmLambdaSimple'(params,body) -> (match (List.find_opt (fun p -> p = name) params) with
                                          | Some(p) -> body_expr
                                          | None -> ScmLambdaSimple'(params,box_parameter_in_body name body))
     | ScmLambdaOpt'(params,optional,body) -> (match (List.find_opt (fun p -> p = name) (optional::params)) with
                                          | Some(p) -> body_expr
                                          | None -> ScmLambdaOpt'(params,optional,box_parameter_in_body name body))
     | ScmApplic'(proc,args) -> ScmApplic'(box_parameter_in_body name proc,(List.map (box_parameter_in_body name) args))
     | ScmApplicTP'(proc,args) -> ScmApplicTP'(box_parameter_in_body name proc,(List.map (box_parameter_in_body name) args))
     | _ -> raise X_this_should_not_happen 
  
  let rec index_of param params i = match params with
      | [] -> raise X_this_should_not_happen
      | hd::tl -> if (hd=param) then i else index_of param tl (i+1)

  let add_boxing parameter minor body_expr =
    match body_expr with
      | ScmSeq'(exprs) -> ScmSeq'(ScmSet'(VarParam(parameter,minor),ScmBox'(VarParam(parameter,minor)))::exprs)
      | expr -> ScmSeq'([ScmSet'(VarParam(parameter,minor),ScmBox'(VarParam(parameter,minor)));expr])

  let box_lambda' parameter parameters body lambda_expr' =
    if (need_to_box lambda_expr' parameter body)
    then let minor = index_of parameter (List.rev parameters) 0 in
         (add_boxing parameter minor (box_parameter_in_body parameter body))
    else body

  let box_all_params params body lambda = List.fold_left (fun acc curr -> box_lambda' curr params acc lambda) body params

  let box_lambda lambda_expr = match lambda_expr with (* need to box the rest of the body (nested lambdas etc...) this will be done in box_set *)
    | ScmLambdaSimple'(params,body) -> ScmLambdaSimple'(params,box_all_params (List.rev params) body lambda_expr)
    | ScmLambdaOpt'(params,opt,body) -> ScmLambdaOpt'(params,opt,box_all_params (List.rev (opt::(List.rev params))) body lambda_expr)
    | _ -> raise X_this_should_not_happen

  let rec box_set expr = match expr with
                          | ScmConst'(sexpr) -> expr
                          | ScmVar'(var') -> expr
                          | ScmIf'(test,dit,dif) -> ScmIf'(box_set test,box_set dit,box_set dif)
                          | ScmSeq'(exprs) -> ScmSeq'(List.map box_set exprs)
                          | ScmSet'(var,value) -> ScmSet'(var,box_set value)
                          | ScmDef'(var,value) -> ScmDef'(var,box_set value)
                          | ScmOr'(exprs) -> ScmOr'(List.map box_set exprs)
                          | ScmLambdaSimple'(parameters,body) -> box_lambda (ScmLambdaSimple'(parameters,box_set body))
                          | ScmLambdaOpt'(parameters,optional,body) -> box_lambda (ScmLambdaOpt'(parameters,optional,box_set body))
                          | ScmApplic'(proc,args) -> ScmApplic'(box_set proc,List.map box_set args)
                          | ScmApplicTP'(proc,args) -> ScmApplicTP'(box_set proc,List.map box_set args)
                          | _ -> raise X_this_should_not_happen

  let run_semantics expr =
    box_set
      (annotate_tail_calls
         (annotate_lexical_addresses expr))

end;; (* end of module Semantic_Analysis *)
